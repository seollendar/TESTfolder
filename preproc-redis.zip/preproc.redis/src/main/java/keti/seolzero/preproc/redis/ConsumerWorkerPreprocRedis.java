package keti.seolzero.preproc.redis;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Pipeline;

public class ConsumerWorkerPreprocRedis implements Runnable {
	/* REDIS */
	String redis_url;
	JedisPoolConfig jedisPoolConfig;
	JedisPool pool;

	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	List<Object> kafkaRecords = new ArrayList<Object>();
	long startP, endP;

	ConsumerWorkerPreprocRedis(Properties prop, String topic, int number, String REDIS_SERVER_IP) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;

		this.jedisPoolConfig = new JedisPoolConfig();
		this.pool = new JedisPool(jedisPoolConfig, REDIS_SERVER_IP, 6379);
	}

	public void run() {
		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		SimpleDateFormat minuteFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
		format.setTimeZone(TimeZone.getTimeZone("GMT"));
		minuteFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		DecimalFormat form = new DecimalFormat("#.###");

		Properties ContainerProperties = new Properties();
		FileInputStream ContainerPropertiesFile;
		String ContainerPropertiespath = "C://eclipsework/preproc.redis/src/main/java/config/container.properties";
		try {
			ContainerPropertiesFile = new FileInputStream(ContainerPropertiespath);
			ContainerProperties.load(ContainerPropertiesFile);
		} catch (IOException e1) {
			System.out.println("[containerProperties read error]" + e1);
		}

		try {

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(100);

				Jedis jedis = pool.getResource();
				Pipeline pipelineForGetPrevData = jedis.pipelined();
				Pipeline pipelineForUpdateData = jedis.pipelined();
				Pipeline jsonDataTimeZoneLpush = jedis.pipelined();
				Pipeline preprocessedDataLpush = jedis.pipelined();
				Pipeline setStartTime = jedis.pipelined();

				if(jedis.get("StartTimeCheck")== null) {
					setStartTime.set("StartTimeCheck", Long.toString(System.currentTimeMillis()));
				}


				for (ConsumerRecord<String, String> record : records) {
					Any jsonObject = JsonIterator.deserialize(record.value());
					//System.out.println(jsonObject);
					Any RecordConObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
					String JsonRecord = RecordConObject.toString();
					String KafkaRecordGetTime = RecordConObject.get("time").toString();
//					System.out.println(JsonRecord);

					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();
					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];
					String container = surSplitArray[5];

					jsonDataTimeZoneLpush.lpush(AE +"/"+ container+"/"+minuteFormat.parse(KafkaRecordGetTime), JsonRecord); //Response long
					//					System.out.println(jsonDataTimeZoneLpush.lpush(AE +"/"+ container+"/"+minuteFormat.parse(KafkaRecordGetTime), JsonRecord));

					if (ContainerProperties.get(container).equals("location")) {
						kafkaRecords.add(jsonObject);
						//									pipelineForGetPrevData.get("previous_" + AE + "_"+ container); 
//						pipelineForGetPrevData.hget(AE + "/"+ container, "previous");//Response string
						pipelineForGetPrevData.hget("key", "previous");
					} else if (ContainerProperties.get(container).equals("timeseries")) {
						System.out.println("time container");
					} else {
						System.out.println("unnamed container");
					}

				} 

				List<Object> results = pipelineForGetPrevData.syncAndReturnAll();//java.util.Collections$EmptyList
				System.out.println(results);

				jsonDataTimeZoneLpush.sync();
				setStartTime.sync();



				for (int i = 0; i < results.size(); i++) {
					try {

						if (results.get(i) == null) {

							Any kafkaRecordObj = (Any) kafkaRecords.get(i);
							Object kafkaRecordConObject = kafkaRecordObj.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
							//System.out.println(kafkaRecordConObject);

							String sur = kafkaRecordObj.get("m2m:sgn").get("sur").toString();
							String[] surSplitArray = sur.split("/");
							String AE = surSplitArray[4];
							String container = surSplitArray[5];
							//									pipelineForUpdateData.set("previous_" + AE + "_"+ container, kafkaRecordConObject.toString());
							pipelineForUpdateData.hset(AE + "/"+ container, "previous" , kafkaRecordConObject.toString());


						} else {

							/* previousData */
							Any PreviousConObject = JsonIterator.deserialize((String) results.get(i));
							double previousLatitude = PreviousConObject.get("latitude").toDouble();
							double previousLongitude = PreviousConObject.get("longitude").toDouble();
							String previousTime = PreviousConObject.get("time").toString();
							long previousTimeParse = 0;
							try {
								previousTimeParse = (format.parse(previousTime)).getTime();
							} catch (ParseException e) {
								e.printStackTrace();
								continue;
							}

							/* CurrentData */
							Any kafkaRecordObj = (Any) kafkaRecords.get(i);
							Any kafkaRecordConObject = kafkaRecordObj.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
							double currentLatitude = kafkaRecordConObject.get("latitude").toDouble();
							double currentLongitude = kafkaRecordConObject.get("longitude").toDouble();
							String currentTime = kafkaRecordConObject.get("time").toString();
							long currentTimeParse = 0;
							try {
								currentTimeParse = (format.parse(currentTime)).getTime();
							} catch (ParseException e) {
								e.printStackTrace();
								continue;
							}

							/* split device AE, container */
							String sur = kafkaRecordObj.get("m2m:sgn").get("sur").toString();
							String[] surSplitArray = sur.split("/");
							String AE = surSplitArray[4];
							String container = surSplitArray[5];



							/* preprocessing vectorizing */
							double preprocessingSpeed = PreprocFunction.getSpeed(previousLatitude, previousLongitude,
									previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
							double preprocessingDistance = PreprocFunction.getDistance(previousLatitude,
									previousLongitude, currentLatitude, currentLongitude);
							double preprocessingDirection = PreprocFunction.getDirection(previousLatitude,
									previousLongitude, currentLatitude, currentLongitude);
							System.out.println("AE: " + AE + " container: " + container + " Time: " + currentTimeParse
									+ "\n    -[Preprocessing]  Speed(m/s) " + preprocessingSpeed + ", Distance(m): "
									+ preprocessingDistance + ", Direction: " + preprocessingDirection);
							String preprocessData = "Speed(m/s): " + preprocessingSpeed + ", Distance(m): "	+ preprocessingDistance + ", Direction: " + preprocessingDirection;
							preprocessedDataLpush.lpush(AE +"/"+ container, preprocessData);

							pipelineForUpdateData.hset(AE +"/"+ container, "previous" , kafkaRecordConObject.toString());
							String count = jedis.llen(AE +"/"+ container+"/"+minuteFormat.parse(previousTime)).toString(); 
							System.out.println("count: "+count);
							pipelineForUpdateData.hset(AE +"/"+ container, "TimeInterval" , count);


						}
					} catch (Exception e) {
						System.out.println("Exception raised(con does not exist): " + e);
						continue;
					}

				} // for
				kafkaRecords.clear();
				pipelineForUpdateData.sync();
				preprocessedDataLpush.sync();
				pipelineForGetPrevData.clear();
				pipelineForUpdateData.close();
				jedis.set("LastTimeCheck", Long.toString(System.currentTimeMillis()));
				jedis.close();
				//						System.out.println(jedis.get("StartTimeCheck") + jedis.get("LastTimeCheck"));


			} // while

		} catch (WakeupException | ParseException e) {
			System.out.println(threadName + " trigger WakeupException" + e);
		} finally {
			System.out.println(threadName + " gracefully shutdown");
			shutdown();
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}
}
