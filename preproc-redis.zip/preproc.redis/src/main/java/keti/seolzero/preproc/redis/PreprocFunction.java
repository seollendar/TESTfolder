package keti.seolzero.preproc.redis;


public class PreprocFunction {


	/*Speed*/
	public static double getSpeed(double previousLatitude, double previousLongitude, long previousTimeParse, double currentLatitude, double currentLongitude, long currentTimeParse) {
		double distanceInMeters = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);//이동거리(m)
		double timeDifference = (double) (currentTimeParse - previousTimeParse)/1000; // 단위:s
		double computedSpeed = computeSpeed(timeDifference, distanceInMeters);//이동속도

		return computedSpeed;
	}

	/*Distance*/
	public static double getDistance(double previousLatitude, double previousLongitude, double currentLatitude, double currentLongitude) {
		double p = 0.017453292519943295;    // Math.PI / 180
		double a = 0.5 - Math.cos((currentLatitude - previousLatitude) * p)/2 + Math.cos(previousLatitude * p) * Math.cos(currentLatitude * p) * (1 - Math.cos((currentLongitude - previousLongitude) * p))/2;
		return (12742 * Math.asin(Math.sqrt(a))*1000);
	} 

	public static double computeSpeed (double timeDifference, double distanceDifference){
		double tspeed;
		if(distanceDifference == 0 || timeDifference == 0){
			tspeed = 0;  
		}else{
			tspeed = distanceDifference / timeDifference;
		}

		return tspeed;
	} 

	/*bearing*/
	public static double getDirection(double latitude1, double longitude1, double latitude2, double longitude2){
		double latitude1_radian = convertdecimaldegreestoradians(latitude1);
		double latitude2_radian = convertdecimaldegreestoradians(latitude2);
		double longitude_diff_radian = convertdecimaldegreestoradians(longitude2-longitude1);
		double y = Math.sin(longitude_diff_radian) * Math.cos(latitude2_radian);
		double x = Math.cos(latitude1_radian) * Math.sin(latitude2_radian) - Math.sin(latitude1_radian) * Math.cos(latitude2_radian) * Math.cos(longitude_diff_radian);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}   

	/*decimal degree -> radian*/
	public static double convertdecimaldegreestoradians(double degree){
		return (degree * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double radian){
		return (radian * 180 / Math.PI);
	}      

	
	
	
}
