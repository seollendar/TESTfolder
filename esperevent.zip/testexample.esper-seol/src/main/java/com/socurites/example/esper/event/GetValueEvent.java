package com.socurites.example.esper.event;

public class GetValueEvent {

    private String name;
    private double value;
	private int latitude;

    public GetValueEvent(String name, double value, int latitude) {
        super();
        this.name = name;
        this.value = value;
        this.latitude = latitude;
    }

    public String getName() {
        return name;
    }

    public double getValue() {
        return value;
    }

    public int getLatitude() {
        return latitude;
    }

}
