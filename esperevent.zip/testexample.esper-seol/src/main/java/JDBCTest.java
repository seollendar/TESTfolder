
import java.sql.*;


public class JDBCTest {

	public static void main(String[] args) {
		Connection con = null;
        Statement st = null;

        String url = "jdbc:postgresql://localhost:5432/spatiodata";
        String user = "postgres";
        String password = "keti123";

        try {
            con = DriverManager.getConnection(url, user, password);
            st = con.createStatement();
            st.executeQuery("insert into java_esper(ae, container, preprocessvalue) values ('yt0', 'location', '6')");

            
        } catch (SQLException sqlEX) {
            System.out.println(sqlEX);
        }
    }
}
