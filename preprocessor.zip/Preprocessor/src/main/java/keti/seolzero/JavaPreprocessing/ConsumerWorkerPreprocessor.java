package keti.seolzero.JavaPreprocessing;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Reader;
import java.text.DecimalFormat;
import java.text.ParseException;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Pipeline;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;

public class ConsumerWorkerPreprocessor implements Runnable {
	/* REDIS */
	String redis_url;
	JedisPoolConfig jedisPoolConfig;
	JedisPool pool;

	/* INFLUX */
	String influx_url;
	InfluxDB influxDB;
	static String dbName = "preprocessedData";

	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	List<Object> kafkaRecords = new ArrayList<Object>();

	ConsumerWorkerPreprocessor(Properties prop, String topic, int number, String INFLUX_SERVER_IP,
			String REDIS_SERVER_IP) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;

		this.influx_url = "http://" + INFLUX_SERVER_IP + ":8086";
		this.influxDB = InfluxDBFactory.connect(influx_url);

		this.jedisPoolConfig = new JedisPoolConfig();
		this.pool = new JedisPool(jedisPoolConfig, REDIS_SERVER_IP, 6379);
	}

	public void run() {
		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		format.setTimeZone(TimeZone.getTimeZone("GMT"));
		DecimalFormat form = new DecimalFormat("#.###");

		Properties ContainerProperties = new Properties();
		FileInputStream ContainerPropertiesFile;
		String ContainerPropertiespath = "C://eclipsework/preproc.redis/src/main/java/config/container.properties";// "container.properties";

		try {
			ContainerPropertiesFile = new FileInputStream(ContainerPropertiespath);
			ContainerProperties.load(ContainerPropertiesFile);
		} catch (IOException e1) {
			System.out.println("[containerProperties read error]" + e1);
		}

		try {

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(100);

				Jedis jedis = pool.getResource();
				Pipeline pipelineForGetPrevData = jedis.pipelined();
				Pipeline pipelineForUpdateData = jedis.pipelined();
				BatchPoints batchPoints = BatchPoints.database(dbName).retentionPolicy("autogen").build();

				for (ConsumerRecord<String, String> record : records) {
					Any jsonObject = JsonIterator.deserialize(record.value());
					//System.out.println(jsonObject);

					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();
					String[] surSplitArray = sur.split("/");
					// System.out.println("surSplitArray: "+ surSplitArray);

					String AE = surSplitArray[4];
					String container = surSplitArray[5];

					if (ContainerProperties.get(container) != null) {
						if (ContainerProperties.get(container).equals("location")) {
							kafkaRecords.add(jsonObject);
							pipelineForGetPrevData.get("previous_" + AE + "_"+ container); 
						} else if (ContainerProperties.get(container).equals("timeseries")) {
							System.out.println("time container");
						} else {
							System.out.println("unnamed container");
						}
					} else {
						System.out.println("null pass");
					}
				} 
				List<Object> results = pipelineForGetPrevData.syncAndReturnAll();

				for (int i = 0; i < results.size(); i++) {
					try {

						if (results.get(i) == null) {

							Any kafkaRecordObj = (Any) kafkaRecords.get(i);
							Object kafkaRecordConObject = kafkaRecordObj.get("m2m:sgn").get("nev").get("rep")
									.get("m2m:cin").get("con");
							//System.out.println(kafkaRecordConObject);

							String sur = kafkaRecordObj.get("m2m:sgn").get("sur").toString();
							String[] surSplitArray = sur.split("/");
							String AE = surSplitArray[4];
							String container = surSplitArray[5];
							pipelineForUpdateData.set("previous_" + AE + "_"+ container, kafkaRecordConObject.toString());

						} else {

							/* previousData */
							Any PreviousConObject = JsonIterator.deserialize((String) results.get(i));
							double previousLatitude = PreviousConObject.get("latitude").toDouble();
							double previousLongitude = PreviousConObject.get("longitude").toDouble();
							String previousTime = PreviousConObject.get("time").toString();
							long previousTimeParse = 0;
							try {
								previousTimeParse = (format.parse(previousTime)).getTime();
							} catch (ParseException e) {
								e.printStackTrace();
								continue;
							}

							/* CurrentData */
							Any kafkaRecordObj = (Any) kafkaRecords.get(i);
							Any kafkaRecordConObject = kafkaRecordObj.get("m2m:sgn").get("nev").get("rep")
									.get("m2m:cin").get("con");
							double currentLatitude = kafkaRecordConObject.get("latitude").toDouble();
							double currentLongitude = kafkaRecordConObject.get("longitude").toDouble();
							String currentTime = kafkaRecordConObject.get("time").toString();
							long currentTimeParse = 0;
							try {
								currentTimeParse = (format.parse(currentTime)).getTime();
							} catch (ParseException e) {
								e.printStackTrace();
								continue;
							}

							/* split device AE, container */
							String sur = kafkaRecordObj.get("m2m:sgn").get("sur").toString();
							String[] surSplitArray = sur.split("/");
							String AE = surSplitArray[4];
							String container = surSplitArray[5];

							/* preprocessing vectorizing */
							double preprocessingSpeed = PreprocFunction.getSpeed(previousLatitude, previousLongitude,
									previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
							double preprocessingDistance = PreprocFunction.getDistance(previousLatitude,
									previousLongitude, currentLatitude, currentLongitude);
							double preprocessingDirection = PreprocFunction.getDirection(previousLatitude,
									previousLongitude, currentLatitude, currentLongitude);

							Point preprocpoint = Point.measurement(AE).time(currentTimeParse, TimeUnit.MILLISECONDS)
									.addField("container", container)
									.addField("preprocessingSpeed", form.format(preprocessingSpeed))
									.addField("preprocessingDistance", form.format(preprocessingDistance))
									.addField("preprocessingDirection", form.format(preprocessingDirection)).build();

							batchPoints.point(preprocpoint);
							System.out.println("AE: " + AE + " container: " + container + " Time: " + currentTimeParse
									+ "\n    -[Preprocessing]  Speed(m/s) " + preprocessingSpeed + ", Distance(m): "
									+ preprocessingDistance + ", Direction: " + preprocessingDirection);
							pipelineForUpdateData.set("previous_" + AE + "_"+ container, kafkaRecordConObject.toString());

						}
					} catch (Exception e) {
						System.out.println("Exception raised(con does not exist): " + e);
						continue;
					}

				} // for
				influxDB.write(batchPoints);
				kafkaRecords.clear();
				pipelineForUpdateData.sync();
				pipelineForGetPrevData.clear();
				pipelineForUpdateData.close();
				jedis.close();

			} // while

		} catch (WakeupException e) {
			System.out.println(threadName + " trigger WakeupException" + e);
		} finally {
			System.out.println(threadName + " gracefully shutdown");
			shutdown();
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}

}