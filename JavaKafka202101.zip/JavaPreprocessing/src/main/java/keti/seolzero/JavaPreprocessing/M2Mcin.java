package keti.seolzero.JavaPreprocessing;

public class M2Mcin {
	String ty;
	String ri;
	String rn;
	String pi;
	String ct;
	String lt;
	String et;
	String st;
	String cr;
	String cnf;
	String cs;
	ConObjectData con;
}
