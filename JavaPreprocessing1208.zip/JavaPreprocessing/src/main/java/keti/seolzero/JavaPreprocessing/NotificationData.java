package keti.seolzero.JavaPreprocessing;

public class NotificationData {
	Nev nev;
	String vrq;
	String sud;
	String sur;
	String cr;
}
