package keti.seolzero.preproc.redis;


import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class ConsumerWithMultiThread {

	private static String REDIS_SERVER_IP;
	private static String TOPIC_NAME = "preprocRedis3"; 
	private static String GROUP_ID = "preprocRedisConsumerGroup";
	private static String BOOTSTRAP_SERVERS; 
	private static String IPpropertiesPath = "C://eclipsework/preproc.redis/src/main/java/config/serverIPSetting.properties"; 
	private static int CONSUMER_COUNT = 3;
	private static List<ConsumerWorkerPreprocRedis> workerThreads = new ArrayList<ConsumerWorkerPreprocRedis>();
	

	public static void main(String[] args) {

		
		Properties IPproperties = new Properties();		
		FileInputStream IPpropertiesFile;
		
		try {
			IPpropertiesFile = new FileInputStream(IPpropertiesPath);
			IPproperties.load(IPpropertiesFile);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		BOOTSTRAP_SERVERS = IPproperties.getProperty("kafka")+":9092"; 
		REDIS_SERVER_IP = IPproperties.getProperty("redis");

		Runtime.getRuntime().addShutdownHook(new ShutdownThread());
		Properties configs = new Properties();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		configs.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");

		ExecutorService executorService = Executors.newCachedThreadPool();
		for (int i = 0; i < CONSUMER_COUNT; i++) {
			ConsumerWorkerPreprocRedis worker = new ConsumerWorkerPreprocRedis(configs, TOPIC_NAME, i, REDIS_SERVER_IP);
			workerThreads.add(worker);
			executorService.execute(worker);

		}
	}
	static class ShutdownThread extends Thread {
		public void run() {
			System.out.println("shut down");
		}
	}
}
