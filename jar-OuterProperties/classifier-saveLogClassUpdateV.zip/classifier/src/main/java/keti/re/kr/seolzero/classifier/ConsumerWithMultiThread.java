package keti.re.kr.seolzero.classifier;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConsumerWithMultiThread {
	private static String INFLUX_SERVER_IP;
	private static String POSTGIS_SERVER_IP;
	private static String TOPIC_NAME = "SmartPortData";
	private static String GROUP_ID = "SmartPortDataClassifierConsumerGroup";
	private static String BOOTSTRAP_SERVERS;
	private static String IPpropertiesPath = "serverIPSetting.properties";
	private static int CONSUMER_COUNT = 5;
	private static List<ConsumerWorkerClassifier> workerThreads = new ArrayList<ConsumerWorkerClassifier>();
	
	
	
	public static void main(String[] args) {
		Properties IPproperties = new Properties();		
		FileInputStream IPpropertiesFile;

		try {
			IPpropertiesFile = new FileInputStream(IPpropertiesPath);
			IPproperties.load(IPpropertiesFile);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		BOOTSTRAP_SERVERS = IPproperties.getProperty("kafka")+":9092"; 
		INFLUX_SERVER_IP =IPproperties.getProperty("Influx");
		POSTGIS_SERVER_IP =IPproperties.getProperty("postGIS");
			
		
		Runtime.getRuntime().addShutdownHook(new ShutdownThread());
		Properties configs = new Properties();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);
		configs.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");

		ExecutorService executorService = Executors.newCachedThreadPool();
		for (int i = 0; i < CONSUMER_COUNT; i++) {
			ConsumerWorkerClassifier worker = new ConsumerWorkerClassifier(configs, TOPIC_NAME, i, INFLUX_SERVER_IP, POSTGIS_SERVER_IP); //ConsumerWorkerClassifier
			workerThreads.add(worker);
			executorService.execute(worker);

		}
	}

	static class ShutdownThread extends Thread {
		public void run() {
			System.out.println("shut down");
		}
	}
}
