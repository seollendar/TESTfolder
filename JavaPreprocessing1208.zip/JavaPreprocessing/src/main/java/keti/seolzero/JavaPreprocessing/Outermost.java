package keti.seolzero.JavaPreprocessing;

public class Outermost {
	NotificationData m2msgn;
}
