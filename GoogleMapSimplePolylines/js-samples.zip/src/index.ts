import axios, { AxiosResponse } from "axios";

interface Post {
   userId: Number;
   id: Number;
   title: String;
   body: String;
}

// async function getData() {
//    //console.log(document.getElementById("textbox") as HTMLInputElement);
//    const textbox = (document.getElementById("textbox") as HTMLInputElement)
//       .value;
//    const params = textbox.split(", ");

//    let gpsPoints = await axios
//       .get(
//          `http://localhost:7979/timeseries/${params[0]}/${params[1]}/period?from=${params[2]}&to=${params[3]}`
//       )
//       .then((result) => {
//          const values: any[] = result.data.values;
//          if (values?.length > 0) {
//             return values?.map((index) => ({
//                lat: index.value.latitude,
//                lng: index.value.longitude,
//             }));
//          } else {
//             return undefined;
//          }
//       });

//    initMap(gpsPoints);
// }

async function getTest() {
   const deviceName = (document.getElementById("device") as HTMLInputElement)
      .value;
   const startTime = (document.getElementById("start") as HTMLInputElement)
      .value;
   const endTime = (document.getElementById("end") as HTMLInputElement).value;
   console.log(deviceName, startTime, endTime);

   let gpsPoints = await axios
      .get(
         `http://localhost:7979/timeseries/${deviceName}/location/period?from=${startTime}&to=${endTime}`
      )
      .then((result) => {
         const values: any[] = result.data.values;
         if (values?.length > 0) {
            return values?.map((index) => ({
               lat: index.value.latitude,
               lng: index.value.longitude,
            }));
         } else {
            return undefined;
         }
      });

   initMap(gpsPoints);
}

import "./style.css";

async function initMap(gpsPoints): Promise<void> {
   console.log(gpsPoints);

   const map = new google.maps.Map(
      document.getElementById("map") as HTMLElement,
      {
         zoom: 14,
         center: { lat: 37.407, lng: 127.116 }, //37.40793174657524, 127.11661849247271 성남시
         mapTypeId: "roadmap", //hybrid, ROADMAP , SATELLITE , terrain
      }
   );

   const flightPlanCoordinates = gpsPoints
      ? gpsPoints
      : [
           { lat: 37.403, lng: 127.159 }, //37.40392550253045, 127.15979672679869
           { lat: 37.41, lng: 127.128 }, //37.41099048571178, 127.12870456242335
           { lat: 37.418, lng: 127.127 }, //37.41889838581559, 127.12793208628979
           { lat: 37.427, lng: 127.144 }, //37.427623375568345, 127.14475489986484
        ];
   const flightPath = new google.maps.Polyline({
      path: flightPlanCoordinates,
      geodesic: true,
      strokeColor: "#FF0000",
      strokeOpacity: 1.0,
      strokeWeight: 2,
   });

   flightPath.setMap(map);
}
// export { initMap, getData, getTest };
export { initMap, getTest };
