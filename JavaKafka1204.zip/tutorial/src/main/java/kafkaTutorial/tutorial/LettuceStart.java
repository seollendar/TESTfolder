package kafkaTutorial.tutorial;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import org.json.JSONObject;

import java.util.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

import io.lettuce.core.*;
import io.lettuce.core.api.StatefulRedisConnection;
import io.lettuce.core.api.sync.RedisCommands;

public class LettuceStart {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

		/*lettuce*/
		RedisClient redisClient = RedisClient.create("redis://127.0.0.1"); 
		//RedisClient redisClient = RedisClient.create("redis://password@localhost:6379/0");
		StatefulRedisConnection<String, String> connection = redisClient.connect();
		RedisCommands<String, String> syncCommands = connection.sync();

		syncCommands.set("key", "Hello, Redis!");

		/*KAFKA*/
		Properties configs = new Properties();
		configs.put("bootstrap.servers", "localhost:9092");     
		configs.put("session.timeout.ms", "10000");             
		configs.put("group.id", "kafka-nodejs-group");          
		configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");    
		configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
		configs.put("fetch.max.wait.ms", "5000");
		configs.put("fetch.min.bytes", "1");
		configs.put("fetch.max.bytes", "104857600");
		configs.put("enable.auto.commit", "false");
		configs.put("max.poll.records", "50000");
		configs.put("auto.offset.reset", "earliest");

		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);            
		consumer.subscribe(Collections.singletonList("fullNotification"));      // topic 설정 notifi(100000)

		int count = 0, message_count = 0;
		try {
			long start = System.currentTimeMillis();
			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				count++;
				for (ConsumerRecord<String, String> record : records) { //String
					String recordOfKafka = record.value();

					String value = syncCommands.get("key");

					message_count++;       
				}
				long end = System.currentTimeMillis();

				if(message_count == 100000) {
					System.out.println( "실행 시간 : " + ( end - start ) + "\ncount: " + count + "\nmessage_count: " + message_count); 
				}

			}
		}finally {          
			consumer.close();
			redisClient.shutdown();
		}

	}
}
