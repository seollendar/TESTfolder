package kafkaTutorial.tutorial;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import org.json.JSONObject;

import java.util.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

public class Consumer_v2 {

    public static void main(String[] args) throws ParseException {
    	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

    	/*REDIS*/
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		JedisPool pool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379, 1000);
		Jedis jedis = pool.getResource();
    	
    	/*KAFKA*/
        Properties configs = new Properties();
        configs.put("bootstrap.servers", "localhost:9092");     
        configs.put("session.timeout.ms", "10000");             
        configs.put("group.id", "kafka-nodejs-group");          
        configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");    
        configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  
        configs.put("fetch.max.wait.ms", "5000");
        configs.put("fetch.min.bytes", "1");
        configs.put("fetch.max.bytes", "104857600");
        configs.put("enable.auto.commit", "false");
        configs.put("max.poll.records", "50000");
        
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);            
        consumer.subscribe(Collections.singletonList("fullNoti"));      // topic 설정 notifi(100000)
        
        int count = 0, message_count = 0;
        try {
        	//long start = System.currentTimeMillis();
	        while (true) {
	        	
	            ConsumerRecords<String, String> records = consumer.poll(1000);
	            count++;
	            for (ConsumerRecord<String, String> record : records) { //String
	            	System.out.println("record.value(): " + record.value());
	            	String recordOfKafka = record.value();
	            	
	        	    JSONObject notiObj = new JSONObject(recordOfKafka);
	        	    JSONObject post1Object = notiObj.getJSONObject("m2m:sgn");
	        	    JSONObject post2Object = post1Object.getJSONObject("nev");
	        	    JSONObject post3Object = post2Object.getJSONObject("rep");
	        	    JSONObject post4Object = post3Object.getJSONObject("m2m:cin");
	        	    JSONObject currentConData = post4Object.getJSONObject("con");
	        	    double currentLatitude = currentConData.getDouble("latitude");
	        		double currentLongitude = currentConData.getDouble("longitude");
	        		String currentTime = currentConData.getString("time");
	        		Date currentTimeParse = format.parse(currentTime);
	        		System.out.println("currentTimeParse: "+ currentTimeParse);

	        	    
	        		
	        	    String getPreviousDataFromRedis = jedis.get("previousData");
	        		if(getPreviousDataFromRedis == null) {
	        			String setStringDataToRedis = currentConData.toString();
		        	    jedis.set("previousData", setStringDataToRedis);	
		        	    System.out.println("redis set");
		        	    
	        		}else {
		        		System.out.println("redis result :" + getPreviousDataFromRedis);
		        		JSONObject PreviousConData = new JSONObject(getPreviousDataFromRedis);
		        		double previousLatitude = PreviousConData.getDouble("latitude");
		        		double previousLongitude = PreviousConData.getDouble("longitude");
		        		String previousTime = PreviousConData.getString("time");
		        		Date previousTimeParse = format.parse(previousTime);
		        		
		        		long Timediff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000;
		        		System.out.println("\n diff: "+ Timediff);
		        		
		        		
		        		/*set previousData to Redis*/
		        		String setStringDataToRedis = currentConData.toString();
		        		jedis.set("previousData", setStringDataToRedis);
	        		}
	        		
	        	    
//	            	message_count++;
//	            	System.out.println("message_count: "+ message_count);	            	
	            }
	            //long end = System.currentTimeMillis();
	            
				/*
				 * if(message_count == 100000) { System.out.println( "실행 시간 : " + ( end - start
				 * ) ); }
				 */
	        	//System.out.println("count: "+ count);
	        	//System.out.println("msg_count: "+ message_count+ "\n"); //sysout 'ctrl+space'
	         
	        }
        }finally {       	
        	consumer.close();
        	pool.close();
        }
    
    }
    
    
    
//    public static double getSpeed(previousData, cinContents) {
//    	   var distancePerM = distance(previousData.latitude, previousData.longitude, cinContents.latitude, cinContents.longitude);//이동거리(m)
//    	    var TimeDiff = (moment(cinContents.time) - moment(previousData.time)/1000); // 단위:s
//    	    var computevelocity = computespeed(TimeDiff, distancePerM);//이동속도
//    	   // console.log("computevelocity",computevelocity);
//    	   
//    	   return computevelocity;
//    }
//    
//    public static double getDistance(previousData, cinContents) {
//    	   var distancePerM = distance(previousData.latitude, previousData.longitude, cinContents.latitude, cinContents.longitude);//이동거리(m)
//    	   // console.log("distancePerM", distancePerM);
//    	   return distancePerM;
//    }
//    
//    public static double getDirection(previousData, cinContents) {
//    	   let direction = getbearing(previousData.latitude, previousData.longitude, cinContents.latitude, cinContents.longitude);
//    	   // console.log("direction", direction);
//    	   return direction;
//    }
    
//    	function distance(lat1, lon1, lat2, lon2){ 
//    	  var p = 0.017453292519943295;    // Math.PI / 180
//    	  var c = Math.cos;
//    	  var a = 0.5 - c((lat2 - lat1) * p)/2 + 
//    	          c(lat1 * p) * c(lat2 * p) * 
//    	          (1 - c((lon2 - lon1) * p))/2;
//
//    	  //console.log(12742 * Math.asin(Math.sqrt(a))*1000)// 2 * R; R = 6371 km
//    	  return (12742 * Math.asin(Math.sqrt(a))*1000);
//    	}
//
//
//    	function computespeed (timediff, distancediff){
//    	  if(distancediff == 0){
//    	    tspeed = 0;  
//    	  }else{
//    	    tspeed = distancediff / timediff;
//    	  }
//    	  //console.log(`speed: ${tspeed} timediff ${timediff} distancediff ${distancediff}`);
//    	  return tspeed;
//    	} 
//
//
//    	function convertdecimaldegreestoradians(deg){
//    	   return (deg * Math.PI / 180);
//    	}
//
//    	/*decimal radian -> degree*/
//    	function convertradianstodecimaldegrees(rad){
//    	   return (rad * 180 / Math.PI);
//    	}
//
//    	/*bearing*/
//    	function getbearing(lat1, lon1, lat2, lon2){
//    	   let lat1_rad = convertdecimaldegreestoradians(lat1);
//    	   let lat2_rad = convertdecimaldegreestoradians(lat2);
//    	   let lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
//    	   let y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
//    	   let x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
//    	   return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
//    	}
  
}
