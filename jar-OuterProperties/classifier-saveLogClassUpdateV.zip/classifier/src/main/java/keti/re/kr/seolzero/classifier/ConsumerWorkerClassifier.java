package keti.re.kr.seolzero.classifier;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;

public class ConsumerWorkerClassifier implements Runnable {

	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	private SimpleDateFormat format;    

	Postgresql Postgresql;
	Influxdb influx;

	ConsumerWorkerClassifier(Properties prop, String topic, int number, String INFLUX_SERVER_IP, String POSTGIS_SERVER_IP) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;

		this.format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		this.format.setTimeZone(TimeZone.getTimeZone("UTC"));

		this.Postgresql = new Postgresql(POSTGIS_SERVER_IP);
		this.influx = new Influxdb(INFLUX_SERVER_IP);

	}


	public void run() {		


		Properties ContainerProperties = new Properties();		
		FileInputStream ContainerPropertiesFile;
		String ContainerPropertiespath = "container.properties"; 

		try {
			ContainerPropertiesFile = new FileInputStream(ContainerPropertiespath);
			ContainerProperties.load(ContainerPropertiesFile);
		} catch (IOException e1) {
			System.out.println("[containerProperties read error]"+ e1);
		}

		try {
			consumer = new KafkaConsumer<String, String>(prop);
			consumer.subscribe(Arrays.asList(topic));
			System.out.println("== classify Module == "+ threadName +" ==");

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				BatchPoints batchPoints = influx.createBatchPoint();

				for (ConsumerRecord<String, String> record : records) {

					Any jsonObject = JsonIterator.deserialize(record.value());

					try {
						Any conObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con"); 
						//System.out.println(conObject);

						/* split device AE, container */
						String sur = jsonObject.get("m2m:sgn").get("sur").toString();
						String[] surSplitArray = sur.split("/");
												
						String AE = surSplitArray[4];        
						String container = surSplitArray[5];  

						if(ContainerProperties.get(container) != null) {
							if(ContainerProperties.get(container).equals("location")) {	
								String sql = Postgresql.createSQL(AE, container, conObject);
								Point point = null;
								try {
									Postgresql.returnStmnt().addBatch(sql);
									point = influx.createPoint(AE, container, conObject);
								} catch (SQLException e) {
									//System.out.println("[SQLException]" + e);
									continue;
								}

								batchPoints.point(point);
								
							}else if(ContainerProperties.get(container).equals("timeseries")) {
								Point point = null;
								try {
									point = influx.createPoint(AE, container, conObject);
								} catch (ParseException e) {
									//System.out.println("[SQLException]" + e);
									continue;
								}
								batchPoints.point(point);
								
							}else {
								System.out.println("unnamed container");
							}
						}else {
							//System.out.println("null pass");
						}
					}catch(Exception e){
						//System.out.println("record Exception raised: " + e);
						continue;
					}

				}//for

				try {
					Postgresql.returnStmnt().executeBatch();
					influx.returnInfluxDBInstance().write(batchPoints);
				} catch (SQLException e) {
					//System.out.println("[SQLException]" + e);
					continue;
				}
				
			}//while

		}catch(Exception e){
			LogSave.write("consumer Exception raised: " + e);
			//System.out.println("consumer Exception raised: " + e);
		} finally {
			LogSave.write(threadName + " gracefully shutdown");
			System.out.println(threadName + " gracefully shutdown");
			shutdown();
		}		

	}

	public void shutdown() {
		consumer.wakeup();
	}


}
