package keti.re.kr.seolzero.classifier;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.TimeZone;

import org.influxdb.InfluxDBFactory;

import com.jsoniter.any.Any;

public class Postgresql {

	private String postgis_url; 
	private String user = "postgres";
	private String password = "portpassword"; 
	private Connection conn;
	private Statement stmnt;
	
	Postgresql(String POSTGIS_SERVER_IP) {
		
		this.postgis_url = "jdbc:postgresql://"+POSTGIS_SERVER_IP+"/spatiodata";
		try {
			System.out.println(postgis_url + user + password);
			this.conn = DriverManager.getConnection(postgis_url, user, password);
			this.stmnt = conn.createStatement();
		} catch (SQLException e) {			
			System.out.println("postgres E: " + e.getMessage());
		}

	}

	
	public Statement returnStmnt() {
		return this.stmnt;
	}
	
	public String createSQL(String ae, String container, Any conObject) {

		Double latitude = conObject.get("latitude").toDouble();
		Double longitude = conObject.get("longitude").toDouble();
		Double altitude = conObject.get("altitude").toDouble();
		Double velocity = conObject.get("velocity").toDouble();
		Double direction = conObject.get("direction").toDouble();
		
		
		String sql = "INSERT INTO spatio (ae, container, latitude, longitude, altitude, velocity, direction, time, gps) "
				+ "VALUES " + "('" + ae + "', '" + container + "', " + latitude + ", " + longitude
				+ ", " + altitude + ", "  + velocity + ", " + direction + ", '" + conObject.get("time") + "', "
				+ "ST_SetSRID(ST_MakePoint(" + longitude + ", " + latitude + "),4326))";
		
		return sql;

	}

}
