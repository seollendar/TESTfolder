package com.socurites.example.esper.listener;
import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

//epl�� �ش��ϴ� �̺�Ʈ�� Ž���� ��� ���� �׼�
public class Listener2 implements UpdateListener {

    public void update(EventBean[] newEvents, EventBean[] oldEvents) {
        EventBean event = newEvents[0];
        //System.out.println("max=" + event.get("max(value)"));
        System.out.println(event);
        //System.out.println("event=" + event.get("value"));
  	    //String name = (String) newEvents[0].get("name");
  	    //int latitude = (int) newEvents[0].get("latitude");
  	    System.out.println(newEvents[0].get("name"));
  	    System.out.println(newEvents[0].get("value"));
    }

}
