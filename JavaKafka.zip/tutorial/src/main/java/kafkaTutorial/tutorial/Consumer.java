package kafkaTutorial.tutorial;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import java.util.*;


public class Consumer {

    public static void main(String[] args) {
        Properties configs = new Properties();
        // 환경 변수 설정
        configs.put("bootstrap.servers", "localhost:9092");     // kafka server host 및 port
        configs.put("session.timeout.ms", "10000");             // session 설정
        configs.put("group.id", "kafka-nodejs-group");                // groupId 설정
        configs.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");    // key deserializer
        configs.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");  // value deserializer
        configs.put("fetch.max.wait.ms", "5000");
        configs.put("fetch.min.bytes", "1");
        configs.put("fetch.max.bytes", "104857600");
        configs.put("enable.auto.commit", "false");
        configs.put("max.poll.records", "50000");
        
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(configs);    // consumer 생성
        
        consumer.subscribe(Collections.singletonList("notifi"));      // topic 설정 notifi(100000)
        
        int count = 0, message_count = 0;
        try {
        	//long start = System.currentTimeMillis();
	        while (true) {
	        	
	            ConsumerRecords<String, String> records = consumer.poll(1000);
	            count++;
	            for (ConsumerRecord<String, String> record : records) {
	            	System.out.println("record.value(): " + record.value());
	            	message_count++;
	            	System.out.println("message_count: "+ message_count);
	            	System.out.println("record.value().getClass().getName(): "+ record.value().getClass().getName());
	            	
	            	
	            }
	            //long end = System.currentTimeMillis();
	            
				/*
				 * if(message_count == 100000) { System.out.println( "실행 시간 : " + ( end - start
				 * ) ); }
				 */
	        	//System.out.println("count: "+ count);
	        	//System.out.println("msg_count: "+ message_count+ "\n"); //sysout 'ctrl+space'
	         
	        }
        }finally {       	
        	consumer.close();
        }
    
    }
    
    
    
//    public static double getSpeed(previousData, cinContents) {
//    	   var distancePerM = distance(previousData.latitude, previousData.longitude, cinContents.latitude, cinContents.longitude);//이동거리(m)
//    	    var TimeDiff = (moment(cinContents.time) - moment(previousData.time)/1000); // 단위:s
//    	    var computevelocity = computespeed(TimeDiff, distancePerM);//이동속도
//    	   // console.log("computevelocity",computevelocity);
//    	   
//    	   return computevelocity;
//    }
//    
//    public static double getDistance(previousData, cinContents) {
//    	   var distancePerM = distance(previousData.latitude, previousData.longitude, cinContents.latitude, cinContents.longitude);//이동거리(m)
//    	   // console.log("distancePerM", distancePerM);
//    	   return distancePerM;
//    }
//    
//    public static double getDirection(previousData, cinContents) {
//    	   let direction = getbearing(previousData.latitude, previousData.longitude, cinContents.latitude, cinContents.longitude);
//    	   // console.log("direction", direction);
//    	   return direction;
//    }
    
//    	function distance(lat1, lon1, lat2, lon2){ 
//    	  var p = 0.017453292519943295;    // Math.PI / 180
//    	  var c = Math.cos;
//    	  var a = 0.5 - c((lat2 - lat1) * p)/2 + 
//    	          c(lat1 * p) * c(lat2 * p) * 
//    	          (1 - c((lon2 - lon1) * p))/2;
//
//    	  //console.log(12742 * Math.asin(Math.sqrt(a))*1000)// 2 * R; R = 6371 km
//    	  return (12742 * Math.asin(Math.sqrt(a))*1000);
//    	}
//
//
//    	function computespeed (timediff, distancediff){
//    	  if(distancediff == 0){
//    	    tspeed = 0;  
//    	  }else{
//    	    tspeed = distancediff / timediff;
//    	  }
//    	  //console.log(`speed: ${tspeed} timediff ${timediff} distancediff ${distancediff}`);
//    	  return tspeed;
//    	} 
//
//
//    	function convertdecimaldegreestoradians(deg){
//    	   return (deg * Math.PI / 180);
//    	}
//
//    	/*decimal radian -> degree*/
//    	function convertradianstodecimaldegrees(rad){
//    	   return (rad * 180 / Math.PI);
//    	}
//
//    	/*bearing*/
//    	function getbearing(lat1, lon1, lat2, lon2){
//    	   let lat1_rad = convertdecimaldegreestoradians(lat1);
//    	   let lat2_rad = convertdecimaldegreestoradians(lat2);
//    	   let lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
//    	   let y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
//    	   let x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
//    	   return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
//    	}
  
}
