package com.socurites.example.esper.listener;
import com.espertech.esper.client.EventBean;
import com.espertech.esper.client.UpdateListener;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


//epl�� �ش��ϴ� �̺�Ʈ�� Ž���� ��� ���� �׼�
public class MyListener implements UpdateListener {

    public void update(EventBean[] newEvents, EventBean[] oldEvents) {
        EventBean event = newEvents[0];
        System.out.println("sum=" + event.get("sum(value)"));
        //System.out.println(event);
        
    }
}



