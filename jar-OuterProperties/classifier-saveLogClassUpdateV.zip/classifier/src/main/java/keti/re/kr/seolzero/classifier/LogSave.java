package keti.re.kr.seolzero.classifier;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class LogSave {
	private static String filePath = "log.txt";

	public static void write(Object o) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd kk:mm:ss", Locale.getDefault());
		String date = sdf.format(cal.getTime());
		String out = "[" + date + "] " + o;
		
		try(BufferedWriter bw = new BufferedWriter(new FileWriter(filePath, true))){
			bw.append(out);
			bw.newLine();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static String getFilePath() {
		return filePath;
	}

	public static void setFilePath(String filePath) {
		LogSave.filePath = filePath;
	}
	

}
