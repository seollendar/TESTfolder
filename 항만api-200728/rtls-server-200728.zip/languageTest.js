const moment = require('moment');

let  time = '2020-06-23 12:00:53'
var Time = moment(time).format('YYYY-MM-DDTHH:mm:ss');
var sTime = moment(time).format('yyyy-MM-DDTHH:mm:ss');

var Rime = moment('24/12/2019 09:15:00', "DD MM YYYY hh:mm:ss");
var rime = moment('24/12/2019 09:15:00', "DD MM yyyy hh:mm:ss");

console.log(Time)
console.log(sTime)
