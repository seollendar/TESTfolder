package keti.seolzero.JavaPreprocessing;

public class ConObjectData {
	String i;
	Double latitude;
	Double longitude;
	Double altitude;
	Double velocity;
	Double direction;
	String time;
	String position_fix;
	String satelites;
	String state;
	
}
