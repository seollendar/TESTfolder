const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const { Client } = require('pg');

const Config = require('./config.json');
const DBConfig = Config.database;

const client = new Client({
  "host": DBConfig.host,
  "port": DBConfig.port,
  "user": DBConfig.user,
  "password": DBConfig.password,
  "database": DBConfig.database
})

client.connect(err => {
  if (err) {
    console.error('Database connection error', err.stack)
  } else {
    console.log('Database connected')
  }
})


app.listen(7980, ()=> {
  console.log("Server Start on port 7980");
})


app.post("/noti_for_fastdata", (req, res)=>{
  //console.log("-------------dataHeader---------------");
  //console.log(req.headers);

  var fullBody = '';
 
 req.on('data', function(chunk) {
    fullBody += chunk; 
  });

  req.on('end', function() {
    //console.log(req.headers);
    //var jsonbody = JSON.parse(fullBody)
    //console.log (jsonbody); 
    //res.status(200).send('post /end test ok');

    
    var jsonbody = JSON.parse(fullBody)
    //console.log("-------------dataBody---------------");
    //console.log(jsonbody);     
    //console.log(jsonbody['m2m:sgn'].nev); 
    //console.log("-------------jsonbody['m2m:sgn'].nev.rep[0]---------------");
    //console.log(jsonbody['m2m:sgn'].nev.rep);

    if(jsonbody['m2m:sgn'].nev.rep['m2m:cin']){
    //console.log("======================\n\n"); 
    //console.log(jsonbody['m2m:sgn'].nev.rep);  
    //console.log("======================\n\n"); 
    //console.log(jsonbody['m2m:sgn'].nev.rep['m2m:cin'].con);  
    //console.log(typeof(jsonbody));

    let cinContents = jsonbody['m2m:sgn'].nev.rep['m2m:cin'].con; //con
    let wtime = cinContents.wtime; //epochtime
    console.log(wtime);
    var utcTime = moment.utc(wtime); //epochtime To UTCzero
    let wtimeUTC = utcTime.format('YYYY-MM-DD HH:mm:ss');
    //console.log(wtimeUTC);
  
    let resources =  req.headers['content-location'].split('/');
    //console.log(resources); 
    //console.log(resources[4]);
    //console.log(resources[5]);

    let ae  = resources [4];
    let container  = resources [5];
  
    let cinContentsData = {
      "ae": ae,
      "container": container,
      "lat": cinContents.lat? cinContents.lat: cinContents.latitude? cinContents.latitude: null,
      "lng": cinContents.lng? cinContents.lng: cinContents.longitude? cinContents.longitude: null,
      "alt": cinContents.alt? cinContents.alt: cinContents.altitude? cinContents.altitude: null,
      "time": wtimeUTC
    }
  
    let saveDataQuery = 'INSERT INTO cincontentsdb (ae, container, latitude, longitude, altitude, creationtime, gps)' +
                        ' values (\''+ ae + '\',\''+ container + '\', \'' + cinContentsData.lat + '\', \'' + cinContentsData.lng + '\', \'' + cinContentsData.alt + '\', \'' + cinContentsData.time + '\', ST_SetSRID(ST_MakePoint('+parseFloat(cinContentsData.lng)+','+parseFloat(cinContentsData.lat)+'),4326))';
  
    console.log (saveDataQuery);
    client.query (saveDataQuery)
    .then (result =>{
      res.status (200 ).send ('Received Location Data');
      console.log (">>> Send Response, 200");
    }).catch (e =>{
      res.status (500 ).send ('Internal Error');
      console .log (e .stack );
    }) 
    }else{
      console.log("Receive other notification message (NOT CIN)")
    }   
    
  });
  

  })

  