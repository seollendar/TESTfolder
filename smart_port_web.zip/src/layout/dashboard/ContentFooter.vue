<template>
  <footer class="footer">
    <div class="container-fluid d-flex flex-wrap justify-content-between">
      <nav>
        <ul>
          <li>
            <p class="footer">IoT Infrastructure Technology for Smart Port</p>
            <p class="footer">Copyright (c) 2022 KETI. All rights reserved.</p>
            <img src="@/assets/img/kimst_logo.png"/>
            <img src="@/assets/img/ministry_of_oceans.jpg"/>
            <img src="@/assets/img/keti_ci.png"/>
          </li>
        </ul>
      </nav>
      <div class="copyright d-flex flex-wrap">
      </div>
    </div>
  </footer>
</template>
<script>
export default {};
</script>
<style>
</style>
