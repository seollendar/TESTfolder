package kafkaTutorial.tutorial;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class TimeTest {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		SimpleDateFormat f = new SimpleDateFormat("2020-11-20'T'HH:mm:ss.SSS"); // 'T' 따옴표 없음 error
		Date d1 = f.parse("2020-11-20T01:05:10.222");
		Date d2 = f.parse("2020-11-20T01:05:07.333");
		long diff = d1.getTime() - d2.getTime();
		long sec = diff / 1000;
		System.out.println(diff);
	}

}


