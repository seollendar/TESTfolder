package keti.re.kr.seolzero.classifier;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.jsoniter.any.Any;

public class Influxdb {
	InfluxDB influxDB; 
	String dbName = "SmartPortData";  
	Point.Builder builder;
	private SimpleDateFormat format; 
	String influx_url;
	
	Influxdb(String INFLUX_SERVER_IP) {
		
		this.influx_url = "http://"+INFLUX_SERVER_IP+":8086";
		this.influxDB = InfluxDBFactory.connect(influx_url);
		
		this.format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		this.format.setTimeZone(TimeZone.getTimeZone("UTC"));
		
	}
	
	public BatchPoints createBatchPoint() {
		BatchPoints batchPoints = BatchPoints.database(dbName).retentionPolicy("autogen").build();
		return batchPoints;
	}

	public Point createPoint(String ae, String container, Any con) throws ParseException, java.text.ParseException {
		Point point;
		JSONParser jParser = new JSONParser();

		this.builder = Point.measurement(ae);
		JSONObject jcon = (JSONObject) jParser.parse(con.toString());

		ArrayList<String> keys = new ArrayList<String> (con.keys());

		for(String key : keys) {
			if(jcon.get(key) instanceof String) {

				if(key.equals("time")) {
					Date TimeParse = this.format.parse((String) jcon.get(key));
					this.builder.time(TimeParse.getTime(), TimeUnit.MILLISECONDS);
				}else {
					this.builder.addField(key, (String) jcon.get(key));
				}

			} else if(jcon.get(key) instanceof Double) {

				this.builder.addField(key, (Double) jcon.get(key));

			} else if(jcon.get(key) instanceof Integer) {

				this.builder.addField(key, (Integer) jcon.get(key));

			}else if(jcon.get(key) instanceof Long) {

				this.builder.addField(key, (Long) jcon.get(key));

			}else if(jcon.get(key) instanceof JSONObject) {

				this.builder.addField(key, (String) jcon.get(key).toString());

			}else if(jcon.get(key) instanceof JSONArray) {

				this.builder.addField(key, (String) jcon.get(key).toString());

			}else {
				System.out.println("else type" + key + jcon.get(key).getClass().getName());
			}
		}

		this.builder.addField("container", (String) container);
		point = builder.build();
		return point;
	}

	public InfluxDB returnInfluxDBInstance() {
		// TODO Auto-generated method stub
		return this.influxDB;
	}   

}
