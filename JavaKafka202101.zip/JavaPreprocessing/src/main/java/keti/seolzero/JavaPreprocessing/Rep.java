package keti.seolzero.JavaPreprocessing;

public class Rep {
	M2Mcin m2mcin;
}
