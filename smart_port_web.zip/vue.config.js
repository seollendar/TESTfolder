
module.exports = {
  lintOnSave: false,
};
