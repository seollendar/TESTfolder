package keti.seolzero.JavaPreprocessing;

public class Nev {
	Rep rep;
}
