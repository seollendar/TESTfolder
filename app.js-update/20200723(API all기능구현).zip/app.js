const express = require('express');
const app = express();
//const http = require('http')
//const server = http.Server(app);
//const bodyParser = require('body-parser');
const { Client } = require('pg');
//const bcrypt = require('bcryptjs');
//const jwt = require('jsonwebtoken');
//const os = require('os');
//var util = require('util');



var cluster = require('cluster'); // 클러스터 모듈 로드
//var express = require('express'); // express 프레임워크 로드
var numCPUs = require('os').cpus().length; // CPU 개수 가져오기
//var SERVER_PORT = 8000; // 애플리케이션 포트 지정

if (cluster.isMaster) { // 마스터 처리
console.log('number of cpu = ' + numCPUs + '\n');

for (var i = 0; i < (numCPUs/2); i++) {
cluster.fork(); // CPU 개수만큼 fork
}
// 워커 종료시 다잉 메시지 출력
cluster.on('exit', function(worker, code, signal) {
console.log('worker ' + worker.process.pid + ' died');
});
}
else { // 워커 처리


  const Config = require('./config.json');
  const DBConfig = Config.database;

  const moment = require('moment');
  const { response } = require('express');
  const client = new Client({
    "host": DBConfig.host,
    "port": DBConfig.port,
    "user": DBConfig.user,
    "password": DBConfig.password,
    "database": DBConfig.database
  })

  client.connect(err => {
    if (err) {
      console.error('Database connection error', err.stack)
    } else {
      console.log('Database connected')
    }
  })
 

  app.listen(7979, ()=> {
    console.log("RTLS-Server Start on port 7979");
  })


  
  app.post("/noti_smart_harbor", (req, res)=>{
    console.log("-------------dataHeader---------------");
    console.log(req.headers);

    var fullBody = '';
    req.on('data', function(chunk) {
      fullBody += chunk;      
    });

    req.on('end', function() {
      var jsonbody = JSON.parse(fullBody)
      console.log("-------------dataBody---------------");
      console.log(jsonbody);     
      console.log("======================\n\n"); 
      console.log(jsonbody['m2m:sgn'].nev.rep);  
      console.log("======================\n\n"); 
      //console.log(jsonbody['m2m:sgn'].nev.rep['m2m:cin'].con);  
      //console.log(typeof(jsonbody));

      let cinContents = jsonbody['m2m:sgn'].nev.rep['m2m:cin'].con; //con
      let wtime = cinContents.wtime; //epochtime
      //console.log(wtime);
      //var utcTime = moment.utc(wtime); //epochtime To UTCzero
      //let wtimeUTC = utcTime.format('YYYY-MM-DD HH:mm:ss');
      //console.log(wtimeUTC);
    
      let resources =  req.headers['content-location'].split('/');
      //console.log(resources); 
      //console.log(resources[4]);
      //console.log(resources[5]);

      let ae  = resources [4];
      let container  = resources [5];
    
      let cinContentsData = {
        "ae": ae,
        "container": container,
        "lat": cinContents.lat? cinContents.lat: cinContents.latitude? cinContents.latitude: null,
        "lng": cinContents.lng? cinContents.lng: cinContents.longitude? cinContents.longitude: null,
        "alt": cinContents.alt? cinContents.alt: cinContents.altitude? cinContents.altitude: null,
        "time": wtime
      }
    
      let saveDataQuery = 'INSERT INTO cincontentsdb (ae, container, latitude, longitude, altitude, time, gps)' +
                          ' values (\''+ ae + '\',\''+ container + '\', \'' + cinContentsData.lat + '\', \'' + cinContentsData.lng + '\', \'' + cinContentsData.alt + '\', \'' + cinContentsData.time + '\', ST_SetSRID(ST_MakePoint('+parseFloat(cinContentsData.lng)+','+parseFloat(cinContentsData.lat)+'),4326))';
    
      console.log (saveDataQuery);
      client.query (saveDataQuery)
      .then (result =>{
        res .status (200 ).send ('Received Location Data');
        console .log (result );
      }).catch (e =>{
        res .status (500 ).send ('Internal Error');
        console .log (e .stack );
      }) 
    })

    })

  app.post("/noti_for_fastdata", (req, res)=>{
    console.log(req.headers);
    console.log(req.body);

    var fullBody = '';
    req.on('data', function(chunk) {
      fullBody += chunk;   
      console.log("-on-");   
    });

    req.on('end', function() {
      req.body = fullBody;
      var jsonbody = JSON.parse(fullBody)
      console.log("-------------dataBody---------------");
      //console.log(jsonbody);     
      //console.log(jsonbody['m2m:sgn'].nev); 
      //console.log("-------------jsonbody['m2m:sgn'].nev.rep[0]---------------");
      //console.log(jsonbody['m2m:sgn'].nev.rep);

      if(jsonbody['m2m:sgn'].nev.rep['m2m:cin']){
      //console.log("======================\n\n"); 
      //console.log(jsonbody['m2m:sgn'].nev.rep);  
      //console.log("======================\n\n"); 
      //console.log(jsonbody['m2m:sgn'].nev.rep['m2m:cin'].con);  
      //console.log(typeof(jsonbody));

      let cinContents = jsonbody['m2m:sgn'].nev.rep['m2m:cin'].con; //con
      let wtime = cinContents.wtime; //epochtime
      console.log(wtime);
      var utcTime = moment.utc(wtime); //epochtime To UTCzero
      let wtimeUTC = utcTime.format('YYYY-MM-DD HH:mm:ss');
      //console.log(wtimeUTC);
    
      let resources =  req.headers['content-location'].split('/');
      //console.log(resources); 
      //console.log(resources[4]);
      //console.log(resources[5]);

      let ae  = resources [4];
      let container  = resources [5];
    
      let cinContentsData = {
        "ae": ae,
        "container": container,
        "lat": cinContents.lat? cinContents.lat: cinContents.latitude? cinContents.latitude: null,
        "lng": cinContents.lng? cinContents.lng: cinContents.longitude? cinContents.longitude: null,
        "alt": cinContents.alt? cinContents.alt: cinContents.altitude? cinContents.altitude: null,
        "time": wtimeUTC
      }
    
      let saveDataQuery = 'INSERT INTO cincontentsdb (ae, container, latitude, longitude, altitude, creationtime, gps)' +
                          ' values (\''+ ae + '\',\''+ container + '\', \'' + cinContentsData.lat + '\', \'' + cinContentsData.lng + '\', \'' + cinContentsData.alt + '\', \'' + cinContentsData.time + '\', ST_SetSRID(ST_MakePoint('+parseFloat(cinContentsData.lng)+','+parseFloat(cinContentsData.lat)+'),4326))';
    
      console.log (saveDataQuery);
      client.query (saveDataQuery)
      .then (result =>{
        res.status (200 ).send ('Received Location Data');
        console.log (">>> Send Response, 200");
      }).catch (e =>{
        res.status (500 ).send ('Internal Error');
        console .log (e .stack );
      }) 
      }else{
        console.log("Receive other notification message (NOT CIN)")
      }   
    })

    })

    

  var testStartRunTime = 0;
  function testRunTimer() {
            var today = new Date(); // 현재시간 얻기
            var runTime = today.getTime(); // 밀리세컨드 ( 1970/01/01 부터 현재까지의 시간을 밀리세컨드로 나타냄 )
            var rtn = 0;
  
            if (testStartRunTime == 0) {
                      testStartRunTime = runTime;
            } else {
                      rtn = (runTime - testStartRunTime) / 1000;
                      testStartRunTime = 0;
            }
            console.log(rtn)
            return rtn;
  } 



  /* GET Retrieve Types    
  * 1. 디바이스 위치 조회
  * 설명 : 디바이스의 아이디를 통해 해당 디바이스의 마지막 위치 조회
  * localhost:7979/location/:deviceID/:containerName/latest
  */
  app.get("/location/:deviceID/:containerName/latest", (req, res) => {
    console.log("------------------------");
    console.log(">>> [/location/:deviceID/:containerName/latest]");
    let {deviceID, containerName} = req.params;
    console.log(">>> ", `deviceID = ${deviceID}, containerName = ${containerName}`);

    //let sql = "SELECT insertdb.deviceid, insertdb.container, insertdb.latitude, insertdb.longitude, insertdb.altitude, insertdb.time, insertdb.ct from (SELECT deviceid, MAX(insertdb.time) as time FROM insertdb where deviceid = '" + deviceID + "'  GROUP BY deviceid)  AS lastvalue, insertdb   WHERE lastvalue.time=insertdb.time AND lastvalue.deviceid=insertdb.deviceid";
    //let sql = "SELECT cincontentsdb.ae, cincontentsdb.container, cincontentsdb.latitude, cincontentsdb.longitude, cincontentsdb.altitude, cincontentsdb.creationtime from (SELECT ae, MAX(cincontentsdb.creationtime) as creationtime FROM cincontentsdb where ae = '" + deviceID + "'  GROUP BY ae)  AS lastvalue, cincontentsdb   WHERE lastvalue.creationtime=cincontentsdb.creationtime AND lastvalue.ae=cincontentsdb.ae";
    let sql = "SELECT spatio.ae, spatio.container, spatio.latitude, spatio.longitude, spatio.altitude, spatio.creationtime from (SELECT ae, MAX(spatio.creationtime) as creationtime FROM spatio where ae = '" + deviceID + "'  GROUP BY ae)  AS lastvalue, spatio   WHERE lastvalue.creationtime=spatio.creationtime AND lastvalue.ae=spatio.ae";


        client.query(sql).then(response => {
          if(response.rowCount){    
            var {ae, container, latitude, longitude, altitude, creationtime, ct} = response.rows[0];
            if(creationtime){
              var time = moment.utc(creationtime).format('YYYYMMDDTHHmmss');
            } else { //if no time
              var time = moment.utc(ct).format('YYYYMMDDTHHmmss');        
            }            
            let parseresponse =  {ae, container, location: {latitude, longitude, altitude}, time};
            res.send(parseresponse);
            console.log(">>> Response:", parseresponse) 
            console.log(">>> 200 OK");
          }else{ //if no response
            res.send("{}");       
            console.log("{}");   
            console.log(">>> 200 OK");   
          }
        }).catch(e => {
          res.status(500).send("Internal Server Error");
          console.log(">>> 500, Internal Server Error...");
          console.log(e.stack);    
        })//client.query        
  });

  /* GET Retrieve Types    
  * 2. 주변 디바이스 조회
  * 설명 : 디바이스의 아이디를 통해 해당 디바이스 주변에 위치하는 다른 디바이스 조회
  * localhost:7979/location/deviceID/containerName/around?radius={distance}&term={seconds}
  */ 
  app.get("/location/:deviceID/:containerName/around", (req, res) => {
    console.log("------------------------");
    console.log(">>> [/location/:deviceID/:containerName/around]");
    let {deviceID, containerName} = req.params;
    //let {radius, term} = req.params;
    //let {radius=500, term=300} = req.query;
    
    if(req.query.radius && req.query.term){
      let radius = req.query.radius? JSON.parse(req.query.radius): 0;
      let term = req.query.term? JSON.parse(req.query.term): 0;
      //console.log(`deviceID = ${deviceID}, containerName = ${containerName}, radius = ${radius}, term = ${term}`);

      /*let sql = "select insertdb.deviceid, insertdb.container, insertdb.latitude, insertdb.longitude, insertdb.altitude, insertdb.time, insertdb.ct from (select insertdb.deviceid, max(insertdb.time) from insertdb WHERE st_DistanceSphere(gps," 
          + " (SELECT insertdb.gps from (SELECT deviceid, MAX(insertdb.time) as time FROM insertdb where deviceid = '" + deviceID + "' GROUP BY deviceid) AS lastvalue, insertdb WHERE lastvalue.time=insertdb.time" 
          + " AND lastvalue.deviceid=insertdb.deviceid)) < " + radius + "AND creationtime::timestamp > NOW() - interval '" + term + "'"
          + " group by deviceid) as lastvalue, insertdb WHERE lastvalue.max = insertdb.time AND lastvalue.deviceid=insertdb.deviceid " 
      
      let sql = "select cincontentsdb.ae, cincontentsdb.container, cincontentsdb.latitude, cincontentsdb.longitude, cincontentsdb.creationtime " +
        "from (" +
        "select cincontentsdb.ae, max(cincontentsdb.creationtime) " +
        "from cincontentsdb " +
        "WHERE st_DistanceSphere(gps, (SELECT DISTINCT cincontentsdb.gps from (SELECT ae, MAX(cincontentsdb.creationtime) as creationtime FROM cincontentsdb where ae = '" + deviceID + "' GROUP BY ae) AS lastvalue, cincontentsdb WHERE lastvalue.creationtime=cincontentsdb.creationtime AND lastvalue.ae=cincontentsdb.ae)) < " + radius + " AND creationtime::timestamp > NOW() - interval '" + term + " sec' " +
        "group by ae) as lastvalue, cincontentsdb " +
        "WHERE lastvalue.max = cincontentsdb.creationtime AND lastvalue.ae=cincontentsdb.ae "
     */
      let sql = "select spatio.ae, spatio.container, spatio.latitude, spatio.longitude, spatio.creationtime " +
      "from (" +
      "select spatio.ae, max(spatio.creationtime) " +
      "from spatio " +
      "WHERE st_DistanceSphere(gps, (SELECT DISTINCT spatio.gps from (SELECT ae, MAX(spatio.creationtime) as creationtime FROM spatio where ae = '" + deviceID + "' GROUP BY ae) AS lastvalue, spatio WHERE lastvalue.creationtime=spatio.creationtime AND lastvalue.ae=spatio.ae)) < " + radius + " AND creationtime::timestamp > NOW() - interval '" + term + " sec' " +
      "group by ae) as lastvalue, spatio " +
      "WHERE lastvalue.max = spatio.creationtime AND lastvalue.ae=spatio.ae "


      client.query(sql).then(response => {
        console.log(sql)
        if(response.rowCount){
          console.log(response.rows)

          var devices = []; 
          for(var index in response.rows){
              if(response.rows[index].ae != deviceID){
                var {ae, container, latitude, longitude, altitude, creationtime, ct} = response.rows[index];
         
                if(!response.rows[index].creationtime){
                  creationtime = ct;
                }
                var time = moment.utc(creationtime).format('YYYYMMDDTHHmmss');
                let parseresponse =  {ae, container, location: {latitude, longitude, altitude}, time};
                devices.push(parseresponse);
              }
          }//for
          res.send({devices});
          console.log({devices})	
          console.log(">>> 200 OK");	
        }else{//if no response
          console.log("{}");
          res.send("{}");  
          console.log(">>> 200 OK");   
        }
      }).catch(e => {
        console.log(e.stack)
        res.status(500).send("Internal Server Error");
        console.log(">>> 500 Internal Server Error");
      })//client.query
    }else{
      res.status(400).send("Bad request");
      console.log("400 Bad request");
    }



    

  });//app.get/around


  /* GET Retrieve Types    
  * 3. 영역 내 디바이스 조회
  * 설명 : 두 개의 GPS좌표를 통해 특정 영역 내 위치하는 디바이스 조회
  * localhost:7979/location/:deviceID/:containerName/speed?from={startDateTime}&to={endDateTime}
  */
  app.get("/location/field", (req, res) => {
    console.log("------------------------");
    console.log(">>> [/location/field]");
    
    //json format이 아니면 err. (),가 없을 시) 
      try{
        JSON.parse(req.query.firstpoint);  //object
        JSON.parse(req.query.secondpoint);
        JSON.parse(req.query.term); //number
      }catch(error){
        console.log("Bad Request: JSON parse error");
        res.status(400).send("Bad Request")
        return;
      }
    
      let firstpoint = req.query.firstpoint? JSON.parse(req.query.firstpoint): 0;  //object
      let secondpoint = req.query.secondpoint? JSON.parse(req.query.secondpoint): 0;
      let term = req.query.term? JSON.parse(req.query.term): 0; //number
    
      //point개수가 2개씩 들어와야 통과.
      if((firstpoint.length != 2) || (secondpoint.length != 2)) {    
        console.log("Bad Request: Input argument count error");
        res.status(400).send("Bad Request");
        console.log(">>> 400 Bad Request");
        return;
      }
    
      let latitudeList  = [];
      let longitudeList = [];
      latitudeList[0]   = firstpoint[0];
      longitudeList[0]  = firstpoint[1];
      latitudeList[1]   = secondpoint[0];
      longitudeList[1]  = secondpoint[1];

      let latitude = [
        latitudeList[0],
        latitudeList[0],
        latitudeList[1],
        latitudeList[1],
        latitudeList[0],
      ];
      let longitude = [
        longitudeList[0],
        longitudeList[1],
        longitudeList[1],
        longitudeList[0],
        longitudeList[0],
      ];
  
      let gpsList = ''
      for(let index = 0; index < latitude.length; index++) {
        gpsList += (index? ', ': '') + longitude[index] + ' ' + latitude[index];
      } 

      getObjectsInSomeSQfield(gpsList, term).then(response => {
        res.send(response);
        console.log(response)
        console.log(">>> 200 OK");
      }).catch(e => {
        res.status(500).send("Internal Server Error");
        console.log(">>> 500 Internal Server Error");
      })
      
    })
    
    function getObjectsInSomeSQfield(gpsList, term) {
      return new Promise((resolve, reject)=>{
        let areaType = ' ST_Contains(ST_SetSRID(ST_MakePolygon(ST_GeomFromText(\'LINESTRING('+ gpsList +')\')), 4326), GPS)';
        
        /*let searchObjectsFromAreaSql = 'select insertdb.deviceid, insertdb.container, insertdb.latitude, insertdb.longitude, insertdb.altitude, insertdb.time from (select insertdb.deviceid, max(insertdb.time) from insertdb ' + areaType + 'group by deviceid) as lastvalue, insertdb WHERE lastvalue.max = insertdb.time AND lastvalue.deviceid=insertdb.deviceid '+
        "AND creationtime::timestamp > NOW() - interval '" + term + "'"
        
        let searchObjectsFromAreaSql = "select cincontentsdb.ae, cincontentsdb.container, cincontentsdb.latitude, cincontentsdb.longitude, cincontentsdb.altitude, cincontentsdb.creationtime " +
        "from ( " +
          "select cincontentsdb.ae, max(cincontentsdb.creationtime) " +
          "from cincontentsdb " +
          "WHERE creationtime::timestamp > NOW() - interval '" + term + " sec' AND " + areaType + " group by ae) as lastvalue, cincontentsdb " +
          "WHERE lastvalue.max = cincontentsdb.creationtime AND lastvalue.ae=cincontentsdb.ae "
        */
        let searchObjectsFromAreaSql = "select spatio.ae, spatio.container, spatio.latitude, spatio.longitude, spatio.altitude, spatio.creationtime " +
        "from ( " +
          "select spatio.ae, max(spatio.creationtime) " +
          "from spatio " +
          "WHERE creationtime::timestamp > NOW() - interval '" + term + " sec' AND " + areaType + " group by ae) as lastvalue, spatio " +
          "WHERE lastvalue.max = spatio.creationtime AND lastvalue.ae=spatio.ae "

        
        
        console.log(searchObjectsFromAreaSql);
        client.query(searchObjectsFromAreaSql).then(response => {
          //console.log(response.rows);
          var devices = [];
          for(var index in response.rows){
            var {ae, container, latitude, longitude, altitude, creationtime, ct} = response.rows[index];
            if(!creationtime){
              creationtime = ct;
            }
            var time = moment.utc(creationtime).format('YYYYMMDDTHHmmss');
            let parseresponse =  {ae, container, location: {latitude, longitude, altitude}, time};        
            devices.push(parseresponse);
          }
          resolve({devices});
        }).catch(e=>{
          console.log(e.stack);
          reject(e);
        })//client.query
      })//return new Promise
    }//function
    
    
    



  /* GET Retrieve Types    
  * 4. 디바이스 누적 이동 거리 조회
  * 설명 : 디바이스의 아이디를 통해 특정 디바이스의 누적 이동 거리 조회
  * localhost:7979/location/:deviceID/:containerName/distance?from={startDateTime}&to={endDateTime}
  */
  app.get("/location/:deviceID/:containerName/distance", (req, res) => {
    let {deviceID, containerName} = req.params;

    if(!req.params.deviceID && !req.query.from && !req.query.to) {
      res.status(400).send("Bad Request");
      console.log("input value error")
    }

    var startdatetime = moment(req.query.from).format('YYYY-MM-DD HH:mm:ss');
    var enddatetime = moment(req.query.to).format('YYYY-MM-DD HH:mm:ss');
    console.log(`deviceID = ${deviceID}, containerName = ${containerName}, from = ${startdatetime}, to = ${enddatetime}`);
    sql = "SELECT st_Length(ST_TRANSFORM(ST_MakeLine(geom.gps),5179)) as distancevalue FROM ( select * from (select * from spatio where ae='"+ deviceID +"') as aevalue "
          + "where creationtime  between '"+ startdatetime +"' and '"+ enddatetime +"' order by creationtime) As geom"
    console.log(sql)
  
    testRunTimer()

    client.query(sql).then(response => {

      

      if(response.rows[0].distancevalue != null){
      //console.log(response.rows[0].distancevalue)
      var returnValues = {}
      returnValues['deviceID'] = deviceID;
      returnValues['container'] = containerName;
      returnValues['value'] = response.rows[0].distancevalue;
      //console.log(returnValues)
      res.send(returnValues);

      testRunTimer()

      }else{
        console.log("{}");
        res.send("{}");  
        console.log(">>> 기간 내 이동거리 없음.");   
      }
      
    }).catch(e => {
    console.log(e.stack)
    res.status(500).send("Internal Server Error");
    console.log(">>> 500 Internal Server Error");
    })//client.query
        
  })


  function getDistanceFromLatLonInKm(array1, array2)
  {
    var lat1 = array1.latitude
    var lng1 = array1.longitude
    var lat2 = array2.latitude
    var lng2 = array2.longitude

    function deg2rad(deg)
    {
        return deg * (Math.PI/180);
    }
    var r = 6371; //지구의 반지름(km)
    var dLat = deg2rad(lat2-lat1);
    var dLon = deg2rad(lng2-lng1);
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon/2) * Math.sin(dLon/2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = r * c; // Distance in km
    return Math.round(d*1000);
  }

  function gettimediff(startpoint, endpoint)
  {
    let starttime = moment(startpoint.creationtime).format("YYYY-MM-DD HH:mm:ss");
    let endtime = moment(endpoint.creationtime).format("YYYY-MM-DD HH:mm:ss");
    let timediffvalue = (moment(endtime).diff(moment(starttime)))/1000
    return timediffvalue;
  }

  function computespeed (startpoint, endpoint)
  {
    let timediff = gettimediff(startpoint, endpoint)
    //console.log("timediff : ",timediff)
    let distancediff = getDistanceFromLatLonInKm(startpoint, endpoint)
    //console.log("distancediff : ", distancediff)
    if(distancediff == 0){
      tspeed = 0;
      
    }else{
      tspeed = timediff / distancediff;
      //console.log("tspeed : ", tspeed)
    }
    return tspeed;
  } 

  /* GET Retrieve Types    
  * 5. 디바이스 누적 평균 이동 속도 조회
  * 설명 : 디바이스의 아이디를 통해 기간 내 디바이스의 이동 속력 평균값 조회
  * localhost:7979/location/:deviceID/:containerName/speed?from={startDateTime}&to={endDateTime}
  */
  app.get("/location/:deviceID/:containerName/speed", (req, res) => {
    let {deviceID, containerName} = req.params;

    testRunTimer()

    if(!req.params.deviceID && !req.query.from && !req.query.to) {
      res.status(400).send("Bad Request");
      console.log("input value error")
    }

    var startdatetime = moment(req.query.from).format('YYYY-MM-DD HH:mm:ss');
    var enddatetime = moment(req.query.to).format('YYYY-MM-DD HH:mm:ss');
    console.log(`deviceID = ${deviceID}, containerName = ${containerName}, from = ${startdatetime}, to = ${enddatetime}`);
    sql = "select * from (select * from spatio where ae='"+ deviceID +"') as aevalue where creationtime  between '"+ startdatetime +"' and '"+ enddatetime +"' order by creationtime"
    

    client.query(sql).then(response =>{
      console.log(sql)
      //console.log(response.rows)
      var rescount = response.rowCount
      if(rescount)
      {	
        let speedsum = 0
        let datacount = 0;
        for(i=0; i<rescount-1; i++)
        {
          let startpoint = response.rows[i];
          let endpoint = response.rows[i+1];
          //console.log("startpoint:", response.rows[i])
          //console.log("endpoint:", response.rows[i+1])
        
          let speed = computespeed(startpoint, endpoint)
          if(speed > 0){
            speedsum += speed;
            datacount++;
          }else{
            ;
          }
  
        }
        //console.log("speedsum:", speedsum)
        let speedaverage = speedsum / datacount;
        
        var returnValues = {};
        returnValues['points'] = rescount; 
        returnValues['deviceID'] = deviceID;
        returnValues['container'] = containerName;
        returnValues['speed'] = speedaverage;
        
        res.send(returnValues);
        //console.log(returnValues);
        console.log(">>> 200 OK");	   
        
        testRunTimer()

      }else
      {
        console.log("이동거리 없음");
        res.send("{}");  
        console.log(">>> 200 OK ");   
      }
    }).catch(e => {
    console.log(e.stack)
    res.status(500).send("Internal Server Error");
    console.log(">>> 500 Internal Server Error");
    })

  })

  /* GET Retrieve Types    
  * 6. 기간별 이동 경로 조회
  * 설명 : 디바이스의 아이디를 통해 기간 내 디바이스의 이동 방향 조회
  * localhost:7979/location/:deviceID/:containerName/direction?from={startDateTime}&to={endDateTime}
  */
  function convertdecimaldegreestoradians(deg){
    return (deg * Math.PI / 180)
  }
  /*decimal radian -> degree*/
  function convertradianstodecimaldegrees(rad){
    return (rad * 180 / Math.PI)
  }

  /*bearing*/
  function getbearing(lat1, lon1, lat2, lon2){
    let lat1_rad = convertdecimaldegreestoradians(lat1)
    let lat2_rad = convertdecimaldegreestoradians(lat2)
    let lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1)
    let y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad)
    let x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad)
    return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360
  }

  app.get("/location/:deviceID/:containerName/direction", (req, res) => {
    let {deviceID, containerName} = req.params;

    if(!req.params.deviceID && !req.query.from && !req.query.to) {
      res.status(400).send("Bad Request");
      console.log("input value error")
    }
    var startdatetime = moment(req.query.from).format('YYYY-MM-DD HH:mm:ss');
    var enddatetime = moment(req.query.to).format('YYYY-MM-DD HH:mm:ss');
    console.log(`deviceID = ${deviceID}, containerName = ${containerName}, from = ${startdatetime}, to = ${enddatetime}`);
    sql = "select * from (select * from spatio where ae='" + deviceID + "') as aevalue where creationtime  between '"+ startdatetime +"' and '"+ enddatetime +"' order by creationtime asc"
  
    testRunTimer()

    client.query(sql)
    //console.log(sql)
    .then(response => {
      var rescount = response.rowCount
      if(rescount){	
        var directionlist = [];
        for(i=0; i<rescount-1; i++)
        {
          let startpoint = response.rows[i];
          let endpoint = response.rows[i+1];
          let direction = getbearing(response.rows[i].latitude, response.rows[i].longitude, response.rows[i+1].latitude, response.rows[i+1].longitude);
          let speed = computespeed (startpoint, endpoint);
          let creationTime = moment.utc(response.rows[i].creationtime).format('YYYYMMDDTHHmmss');
          directionlist.push({direction, speed, creationTime}) 
        }
        //console.log("directionlist", directionlist)	
        var returnValues = {};
        returnValues['points'] = rescount;
        returnValues['deviceID'] = deviceID;
        returnValues['container'] = containerName;
        returnValues['values'] = directionlist;
        res.send(returnValues);
        //console.log(returnValues);
        console.log(">>> 200 OK");	

        testRunTimer()
          
      }else{//if no response
        console.log("{}");
        res.send("{}");  
        console.log(">>> 200 OK");   
      }
      }).catch(e => {
      console.log(e.stack)
      res.status(500).send("Internal Server Error");
      console.log(">>> 500 Internal Server Error");
      })//client.query
  })



  



  /* GET Retrieve Types    
  * 7. 기간별 이동 경로 조회
  * 설명 : 디바이스의 아이디를 통해 기간 내 디바이스의 이동 경로 조회
  * localhost:7979/location/:deviceID/:containerName/trajectory?from={startDateTime}&to={endDateTime}
  */
  app.get("/location/:deviceID/:containerName/trajectory", (req, res) => {
    let {deviceID, containerName} = req.params;

    if(!req.params.deviceID && !req.query.from && !req.query.to) {
      res.status(400).send("Bad Request");
      console.log("input value error")
    }
    var startdatetime = moment(req.query.from).format('YYYY-MM-DD HH:mm:ss');
    var enddatetime = moment(req.query.to).format('YYYY-MM-DD HH:mm:ss');
    console.log(`deviceID = ${deviceID}, containerName = ${containerName}, from = ${startdatetime}, to = ${enddatetime}`);
    sql = "select * from (select * from spatio where ae='" + deviceID + "') as aevalue where creationtime  between '"+ startdatetime +"' and '"+ enddatetime +"' order by creationtime asc"
    
    client.query(sql)     
    .then(response => {
      console.log(sql)
      testRunTimer()

      if(response.rowCount){	
        var returnValues = {};
        var trajectory = [];

        for(var index in response.rows){
          let latitude = response.rows[index].latitude
          let longitude = response.rows[index].longitude
          let altitude = response.rows[index].altitude
          var time = moment.utc(response.rows[index].creationtime).format('YYYYMMDDTHHmmss');
          trajectory.push({location: {latitude, longitude, altitude}, time});
        }//for
        returnValues['points'] = response.rowCount;
        returnValues['deviceID'] = deviceID;
        returnValues['container'] = containerName;
        returnValues['trajectory'] = trajectory;
        res.send(returnValues);
        console.log(returnValues);
        console.log(">>> 200 OK");	
      }else{//if no response
        console.log("{}");
        res.send("{}");  
        console.log(">>> 200 OK");   
      }

      testRunTimer()

      }).catch(e => {
      console.log(e.stack)
      res.status(500).send("Internal Server Error");
      console.log(">>> 500 Internal Server Error");
      })//client.query
    
  })





  //The 404 Route (ALWAYS Keep this as the last route)
  app.get('*', function(req, res){
    res.send("Bad Request (Wrong Url)", 404);
  });

  app.post('*', function(req, res){
    res.send("Bad Request (Wrong Url)", 404);
  });


}