package kafkaTutorial.tutorial;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import org.json.simple.parser.ParseException;
import org.json.JSONObject;


public class Jedistest {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		JedisPool pool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379, 1000);
		// Jedis풀 생성(JedisPoolConfig, host, port, timeout, password)
		Jedis jedis = pool.getResource();// thread, db pool처럼 필요할 때마다 getResource()로 받아서 쓰고 다 쓰면 close로 닫아야 한다.
		 

		String notiRedisData =  "{\"m2m:sgn\":{\"nev\":{\"rep\":{\"m2m:cin\":{\"ty\":4,\"ri\":\"cin00S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"rn\":\"cin-S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"pi\":\"cnt00000000000001951\",\"ct\":\"20201022T160131\",\"lt\":\"20201022T160131\",\"et\":\"20201121T160131\",\"st\":903335,\"cr\":\"SS01228427453\",\"cnf\":\"application/json\",\"cs\":155,\"con\":{\"i\":992,\"latitude\":28.4966018,\"longitude\":129.0953344,\"altitude\":12.934,\"velocity\":0,\"direction\":0,\"time\":\"2020-12-01T04:04:04\",\"position_fix\":1,\"satelites\":0,\"state\":\"ON\"}}},\"om\":{\"op\":1,\"org\":\"SS01228427453\"}},\"vrq\":false,\"sud\":false,\"sur\":\"/~/CB00061/smartharbor/dt1/scnt-location/sub-S01228427453_user\",\"cr\":\"SS01228427453\"}}";
		
		jedis.set("notiRedisData", notiRedisData);

		String getCinDataFromRedis = jedis.get("notiRedisData");
		//System.out.println("result :" + getCinDataFromRedis);
		//System.out.println("type: " + getCinDataFromRedis.getClass().getName()); //String
		
	    JSONObject notiObj = new JSONObject(getCinDataFromRedis);
	    JSONObject post1Object = notiObj.getJSONObject("m2m:sgn");
	    JSONObject post2Object = post1Object.getJSONObject("nev");
	    JSONObject post3Object = post2Object.getJSONObject("rep");
	    JSONObject post4Object = post3Object.getJSONObject("m2m:cin");
	    JSONObject post5Object = post4Object.getJSONObject("con");
	    Object altitude = post5Object.get("altitude"); //Double
	    System.out.println("altitude :" + altitude);
		
		
		
		
		if (jedis != null) {
			jedis.close();
		}
		pool.close();
	}

}
